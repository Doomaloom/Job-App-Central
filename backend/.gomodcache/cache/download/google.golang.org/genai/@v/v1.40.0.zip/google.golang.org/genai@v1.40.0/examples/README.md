# Go Examples

This directory contains examples of using the `google.golang.org/genai` library.

For more examples, see https://github.com/google-gemini/api-examples/tree/main/go
