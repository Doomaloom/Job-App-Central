# Contributing

The Google Gen AI SDK is will accept contributions in the future.